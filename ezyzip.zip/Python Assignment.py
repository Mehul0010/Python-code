text = """3
hack
indiahacks
code
eddy
coder
iamredoc
"""

cases=text.split()[1:]



for i in range(0, len(cases), 2):
    pattern = cases[i]
    text_string = cases[i+1]

    # print(pattern, text_string)
    if set(pattern).issubset(set(text_string)):
        print("YES")
    else:
        print("NO")